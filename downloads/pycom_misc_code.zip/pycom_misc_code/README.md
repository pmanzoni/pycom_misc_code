# pycom_misc_code
Misc code for the labs session based on PyCom devices, like LoPy, PySense, ...

The main repository for PyCom devices is here:  https://github.com/pycom/pycom-libraries. 
It contains out of the box examples and Python utility `classes` for Pycom devices (including Pysense and Pytrack).

MQTT required library can be found there.
